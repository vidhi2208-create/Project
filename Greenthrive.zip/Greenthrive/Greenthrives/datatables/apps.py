from django.apps import AppConfig


class DatatablesConfig(AppConfig):
    name = 'datatables'
