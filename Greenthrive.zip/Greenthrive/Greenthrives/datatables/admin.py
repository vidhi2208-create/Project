from django.contrib import admin
from datatables.models import *

admin.site.register(user)
admin.site.register(address)
admin.site.register(helps)
admin.site.register(category)
admin.site.register(product)
admin.site.register(order)
admin.site.register(feedback)
admin.site.register(help_subject)
admin.site.register(product_details)
admin.site.register(gallary)
admin.site.register(orderdetails)
admin.site.register(cart)

# Register your models here.



