from django.db import models

class user(models.Model):
	CHOICES=(('M','Male'),('F','Female'))
	user_name=models.CharField(max_length=50)
	email=models.CharField(max_length=50)
	password=models.CharField(max_length=50)
	dob=models.DateField()
	contact=models.CharField(max_length=11)
	gender=models.CharField(max_length=1,choices=CHOICES)
	def __str__(self):
		return self.user_name


class address(models.Model):
	house_no=models.CharField(max_length=8)
	building_name=models.CharField(max_length=20)
	landmark=models.CharField(max_length=100)
	city=models.CharField(max_length=20)
	address_type=models.CharField(max_length=20)
	user_id=models.ForeignKey(user,on_delete=models.CASCADE)
	

class category(models.Model):
	category_name=models.CharField(max_length=20)
	category_desc=models.CharField(max_length=50)
	parent_category=models.ForeignKey('self',on_delete=models.CASCADE,null = True,blank = True)
	def __str__(self):
		return self.category_name
	
class order(models.Model):
	order_date=models.DateField()
	order_status=models.CharField(max_length=2)
	payment_status=models.CharField(max_length=1)
	user_id=models.ForeignKey(user,on_delete=models.CASCADE)
	def __str__(self):
		return self.user_id.user_id

class product(models.Model):
	product_name=models.CharField(max_length=20)
	product_description=models.CharField(max_length=100)
	category_id=models.ForeignKey(category,on_delete=models.CASCADE)
	def __str__(self):
		return self.product_name

class product_details(models.Model):
	product_date=models.DateField()
	product_price=models.CharField(max_length=6)
	product_qty=models.CharField(max_length=3)
	product_id=models.ForeignKey(product,on_delete=models.CASCADE)
	
class order_details(models.Model):
	product_id=models.ForeignKey(product,on_delete=models.CASCADE)
	productdetails_id=models.ForeignKey(product_details,on_delete=models.CASCADE)
	cart_id=models.ForeignKey(cart,on_delete=models.CASCADE)
	def __str__(self):
		return self.product_id.product_id

class cart(models.Model):
	qty=models.CharField(max_length=5)
	amount=models.CharField(max_length=7)
	added_date=models.DateField()
	product_id=models.ForeignKey(product,on_delete=models.CASCADE)
	user_id=models.ForeignKey(user,on_delete=models.CASCADE)

 
class feedback(models.Model):
	feedback_desc=models.CharField(max_length=150)
	feedback_date=models.DateField()
	feedback_reply=models.CharField(max_length=150)
	order_id=models.ForeignKey(order,on_delete=models.CASCADE)
	def __str__(self):
		return self.order_id.order_id




class gallary(models.Model):
	gallary_path=models.ImageField()
	product_id=models.ForeignKey(product,on_delete=models.CASCADE)
	def __str__(self):
		return self.product_name.product_name




class help_subject(models.Model):
	subject_name=models.CharField(max_length=10)
	subject_desc=models.CharField(max_length=200)
	def __str__(self):
		return self.subject_name

class helps(models.Model):
	help_desc=models.CharField(max_length=200)
	help_date=models.DateField()
	help_response=models.CharField(max_length=200)
	help_image1=models.ImageField(null = True,blank = True)
	user_id=models.ForeignKey(user,on_delete=models.CASCADE)
	subject_id=models.ForeignKey(help_subject,on_delete=models.CASCADE)
	def __str__(self):
		return self.user_name.user_name


	# Create your models here.


